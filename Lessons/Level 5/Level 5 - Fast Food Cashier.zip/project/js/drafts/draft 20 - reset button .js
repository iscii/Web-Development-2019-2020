
//currency
const B20 = 0, B10 = 1, B5 = 2, B1 = 3, Q = 4, D = 5, N = 6, P = 7;
const VALUES = [20, 10, 5, 1, 0.25, 0.10, 0.05, 0.01];
const TAX = 1.08875;
//menu
const ENTREES = ["Hamburger;1.99", "Chicken_Sandwich;1.99", "Veggie_Sandwich;2.29"];
const SIDES = ["French_Fries;0.99", "Salad;1.39", "Cheese_Sticks;1.49", "Rice;1.19"];
const DESSERTS = ["Ice_Cream;1.89", "Pie;1.69", "Cookie;0.89"];
const DRINKS = ["Soda;1.19", "Bottled_Water;1.25", "Juice;1.69"];
const FOODTYPES = ["ENTREES", "SIDES", "DESSERTS", "DRINKS"];

function initialize(){
    iVars();
    iRefs();
}
function iRefs(){
    opLog = document.getElementById("logframe");
    clStyleReceipts = document.getElementsByClassName("receipts");
    clStyleSims = document.getElementsByClassName("cSims");
    inputRepeat = document.getElementById("repeatForm");
    inputShift = document.getElementById("shiftForm");

    opItemAvgs = document.getElementById("itemavgs");
    opSaleAvgs = document.getElementById("saleavgs");
    opRegBalAvgs = document.getElementById("regbalavgs");
    opNumSims = document.getElementById("numsims");

    //itemcost
    opHamburgerCost = document.getElementById("avghamburgercost"); //lost of repeat code. Is there a way to shorten it?
    opChicken_SandwichCost = document.getElementById("avgchickensandwichcost");
    opVeggie_SandwichCost = document.getElementById("avgveggiesandwichcost");
    opFrench_FriesCost = document.getElementById("avgfrenchfriescost");
    opSaladCost = document.getElementById("avgsaladcost");
    opCheese_SticksCost = document.getElementById("avgcheesestickscost");
    opRiceCost = document.getElementById("avgricecost");
    opIce_CreamCost = document.getElementById("avgicecreamcost");
    opPieCost = document.getElementById("avgpiecost");
    opCookieCost = document.getElementById("avgcookiecost");
    opSodaCost = document.getElementById("avgsodacost");
    opBottled_WaterCost = document.getElementById("avgbottledwatercost");
    opJuiceCost = document.getElementById("avgjuicecost");

    //itemcount
    opHamburgerCount = document.getElementById("avghamburgercount");
    opChicken_SandwichCount = document.getElementById("avgchickensandwichcount");
    opVeggie_SandwichCount = document.getElementById("avgveggiesandwichcount");
    opFrench_FriesCount = document.getElementById("avgfrenchfriescount");
    opSaladCount = document.getElementById("avgsaladcount");
    opCheese_SticksCount = document.getElementById("avgcheesestickscount");
    opRiceCount = document.getElementById("avgricecount");
    opIce_CreamCount = document.getElementById("avgicecreamcount");
    opPieCount = document.getElementById("avgpiecount");
    opCookieCount = document.getElementById("avgcookiecount");
    opSodaCount = document.getElementById("avgsodacount");
    opBottled_WaterCount = document.getElementById("avgbottledwatercount");
    opJuiceCount = document.getElementById("avgjuicecount");

    //sales
    opAvgTotalSaleV = document.getElementById("avgtotalsalevalue");
    opAvgElecSaleV = document.getElementById("avgelecsalevalue");
    opAvgCashSaleV = document.getElementById("avgcashsalevalue");
    opAvgTotalSaleC = document.getElementById("avgtotalsalecount");
    opAvgElecSaleC = document.getElementById("avgelecsalecount");
    opAvgCashSaleC = document.getElementById("avgcashsalecount");

    //register balance
    opRegBalValue = document.getElementById("regbalval");
}
//note: Instead of using floats for calculations, you could just use integers (100 for 1$) and then convert it to a float when it needs to be displayed. (Credits to Steven Hsui)
function iVars(){ //updating between simulations
    //sequencing
    canSimulate = true;
    simNum = 0;

    //enhancement 2
    logData = []; //holds the totals of every simulation overall
    avgRegisterBal = 0;
    avgTotalSales = 0;
    avgTotalSalesTotal = 0;
    avgCashSales = 0;
    avgCashSalesTotal = 0;
    avgElecSales = 0;
    avgElecSalesTotal = 0;
    avgEntreeTotals = ["0;0", "0;0", "0;0"]; //count;revenue;times averaged -- enhancement 2
    avgSideTotals = ["0;0", "0;0", "0;0", "0;0"];
    avgDessertTotals = ["0;0", "0;0", "0;0"];
    avgDrinkTotals = ["0;0", "0;0", "0;0"];
    avgTotalTypes = ["avgEntreeTotals", "avgSideTotals", "avgDessertTotals", "avgDrinkTotals"];

    //css
    clReceiptWidth = 0; //class "receipts"
    clOrdersWidth = 0; //class "orders"

    repeatCount = 0;
}
function semiVars(){ //changing/reset between simulations
    //semi-dynamic
    register = [0, 2, 4, 42, 40, 50, 40, 100];
    registerTotal = 0;
    numOrder = 0;
    orderTime = 0;//shift length (in minutes)
    time = 180;
    if(inputShift.shiftlength.value)
        time = (inputShift.shiftlength.value * 60);
    exactChange = false;
    numCashSales = 0;
    numElecSales = 0;
    totalCashSales = 0;
    totalElecSales = 0;

    simEntreeTotals = ["0;0", "0;0", "0;0"]; //count;revenue
    simSideTotals = ["0;0", "0;0", "0;0", "0;0"];
    simDessertTotals = ["0;0", "0;0", "0;0"];
    simDrinkTotals = ["0;0", "0;0", "0;0"];
    simTotalTypes = ["simEntreeTotals", "simSideTotals", "simDessertTotals", "simDrinkTotals"];
}
function dynamicVars(){ //changing/reset within each iteration of simulation
    //dynamic
    change = 0;
    order = [];
    orderSubTotal = 0;
    orderTotal = 0;
    orderTax = 0;
    cash = [];
    cashGiven = 0;
    paymentMethod = "Cash";
}
function run(){
    repeatCount = inputRepeat.runcount.value;
    if(!repeatCount && canSimulate){
        canSimulate = false;
        simulate();
        setTimeout(cooldown, 1000);
    }
    if(repeatCount){ //figure out how to time the simulation so that it slowly performs each simulation upon repeat and does not lag out the computer -> probably requires some sort of settimeout or async await?
        for(y = 0; y < repeatCount; y++){ //for some reason, setting this to i ruins the for loop -> sometimes the iteration is skipped. Probably cos simulate() uses so many i vars to the point where it interferes with this one.
            simulate();
            //display();
        }
    }
}
function reset(){ //refreshes page
    location.reload();
}
function simulate(){ //split into functions primarily for organization and readability
    simNum++; //update simulation number
    console.log("SIM " + simNum);
    semiVars();
    dynamicVars();
    dispOrder();
    console.log("1: " + opSims.innerHTML);
    for(time; time > 0; time -= (orderTime + breakTime)){
        numOrder++;
        console.log("--------------------------------------------- ORDER [" + numOrder + "] ---------------------------------------------");
        //determines the order's length in time
        orderTime = getRandomInteger(1, 5);
        breakTime = getRandomInteger(0, 2);
        if((time - (orderTime + breakTime) <= 0)){
            breakTime = 0;
            orderTime = time;
        }
        console.log("[Note] Length: " + orderTime);
        console.log("[Note] Break: " + breakTime);
        console.log("[Note] Total Length: " + (orderTime + breakTime));
        dOrder(); //d for 'determine'
        dCost();
        dPaymentMethod();
        dispReceipt();
        dynamicVars();
    }
    console.log("2: " + opSims.innerHTML);
    display();
    console.log("[Note] Remaining time: " + time);
}
function cooldown(){ //small code for setTimeout (prevents spamming the button while simulation is in progress, potentially messing up the arrays?)
    canSimulate = true;
}
function dOrder(){
    var foodNum = 0;
    var placeHolder;
    var drinkNum = getRandomInteger(0, 2); //drinks are not in loop cos there has to be at least one (could've probably put it in loop tho)
    for (i = 0; i < (FOODTYPES.length - 1); i++){
        if(i == 1)
            quantity = getRandomInteger(0, 2);
        else
            quantity = getRandomInteger(0, 1);
        for (x = 0; x < quantity; x++){
            foodNum = getRandomInteger(0, (eval(FOODTYPES[i]).length - 1));
            order.push(eval(FOODTYPES[i])[foodNum]);
            placeHolder = eval(simTotalTypes[i])[foodNum].split(";");
            placeHolder[0]++;
            placeHolder[1] = (parseFloat(placeHolder[1]) + parseFloat(eval(FOODTYPES[i])[foodNum].split(";")[1])).toFixed(2);
            eval(simTotalTypes[i])[foodNum] = placeHolder.join(";");
        }
    }
    order[order.length] = eval(FOODTYPES[3])[drinkNum]; //sets the first (drink)
    placeHolder = eval(simTotalTypes[3])[drinkNum].split(";");
    placeHolder[0]++;
    placeHolder[1] = (parseFloat(placeHolder[1]) + parseFloat(eval(FOODTYPES[3])[drinkNum].split(";")[1])).toFixed(2);
    eval(simTotalTypes[3])[drinkNum] = placeHolder.join(";");
    console.log(order);
}
function dCost(){
    for (i = 0; i < order.length; i++)
        orderSubTotal += parseFloat(order[i].split(";")[1]);
    orderSubTotal = orderSubTotal.toFixed(2); //rounds to two decimal places (sometimes floating-point error)
    console.log("Subtotal: " + orderSubTotal); //subtotal
    orderTotal = (orderSubTotal * TAX).toFixed(2);
    orderTax = (orderTotal - orderSubTotal).toFixed(2);
    console.log("Tax: " + orderTax); //tax
    console.log("Total: " + orderTotal); //total
}
function dPaymentMethod(){
    var x = getRandomInteger(1, 10);
    var isExactChange;
    if(x <= 4){
        paymentMethod = "Cash";
        x = getRandomInteger(1, 10);
        if(x == 1){
            isExactChange = true;
            cashGiven = orderTotal;
        }
        else{
            isExactChange = false;
            dCash();
        }
        change = (cashGiven - orderTotal).toFixed(2);
        totalCashSales += parseFloat(orderTotal);
        totalCashSales = roundDecimal(totalCashSales, 2);
        registerChange(isExactChange);
        numCashSales++;
        console.log("Cash: " + cashGiven);
        console.log("Change: " + change);
        console.log("Register: " + register);
    }
    else{
        //something extra
        var r = getRandomInteger(0, 4);
        var methods = ["Debit", "Credit", "Google Pay", "Apple Pay", "Gift Card"];
        paymentMethod = methods[r];
        cashGiven = orderTotal;
        totalElecSales += parseFloat(orderTotal);
        totalElecSales = roundDecimal(totalElecSales, 2);
        numElecSales++;
        console.log("Electronic: " + orderTotal);
    }
}
function dCash(){
    cash = [1, getRandomInteger(0, 2), getRandomInteger(0, 3), getRandomInteger(0, 5)]
    console.log("[Note] Customer bills carried: " + cash);
    var billsGiven = [];
    var quantItem;
    //determines cash payment from the lowest denominator
    for(i = 3; i >= 0; i--){ //check lowest value, add from lowest up. If cannot pay for total, check next value, add from lowest up, etc...
        if(cash[i] > 0){
            for(x = 3; x >= i; x--){ //3 being cash[3]
                cashGiven = VALUES[i]; // FIXES ../bugs/1.27.19_-_cash.png
                billsGiven = [VALUES[i]]; 
                if(cashGiven - orderTotal >= 0){
                    payToRegister(billsGiven);
                    return;                                                      
                }
                if(x == i)
                    quantItem = (cash[x] - 1);           
                else
                    quantItem = cash[x];

                for(o = 0; o < quantItem; o++){
                    cashGiven += VALUES[x];
                    billsGiven.push(VALUES[x]);
                    if(cashGiven - orderTotal >= 0){
                        payToRegister(billsGiven);
                        return;
                    }
                }
            }
        }
    }
}
function payToRegister(array){ //cannot put in dCash - check /drafts/draft 15 and ../bugs/2.7.20. Also, require specific bills to be added.
    var billsGiven = array;
    console.log("[Note] Paid in " + billsGiven); 
    var constname;
    for(i = 0; i < billsGiven.length; i++){
        constname = "B" + billsGiven[i];
        register[eval(constname)]++;
    }
}
function registerChange(isExactChange){
    console.log("[Note] Register b/f change: " + register);
    if(!isExactChange){
        var isDone = false;
        var tempChange = change;
        //break down the change from the largest possible denominations
        loop: for(x = B20; x <= P; x++){ //See ../references (Continue/break for loops)
            for(o = 0; o <= register[x]; o++){
                if((o > 10) && (x >= 4)) //none of the coin* counts (*hence x >= 4) can go beyond 10 without being replacable by the next value coin. Prevents ~86 iterations before next loop
                    continue loop; //passes control to next iteration
                if(!isDone) //doing this cos if checkForDrops is called, isDone must be false.
                    updateRegister(); 
                function updateRegister(){ //nested function
                    if(tempChange - VALUES[x] >= 0){
                        if(register[x]){ 
                            register[x]--;
                            tempChange -= VALUES[x];
                            tempChange = tempChange.toFixed(2);
                            if(tempChange == 0){
                                console.log("[Note] Register a/f change: " + register);
                                return isDone = true;
                            }
                            return tempChange;
                        }
                        else{
                            console.log("[Event] Register [" + x + "] " + "is empty! Checking for drops..");
                            if(x >= 4)
                                checkForDrops();
                        }
                    }
                }
                if(!register[x]){ //if the currency type is still unreplaced, skip to next value
                    console.log("[Note] Skipped register [" + x + "] ");
                    continue loop; //is out of the updateRegister() function since I don't know of a way to access a loop from a nested function
                }
                
                function checkForDrops(){ //enhancement
                    var roll = [0, 0, 0, 0, 40, 50, 40, 100]; //the coin count of its corresponding roll
                    var quantity;
                    var greater = (x - 3); //sets the larger "droppable" values to the third denomination up from the objective value
                    //check for which coin needs drop; then, check which larger bills are available for exchange.
                    for(o = greater; o <= 7; o++){
                        quantity = ((roll[x] * VALUES[x]) / VALUES[o]); //added VALUES[x] -- might've fixed the issue check it out
                        if(register[o] >= quantity){
                            register[o] -= quantity;
                            register[x] += roll[x];
                            console.log("[Event (Drop)] Exchanged [" + quantity + "] of " + "register [" + o + "]"  + " for [" + roll[x] + "] of register [" + x + "]");
                            updateRegister();
                            return;
                        }
                    }
                }
            }
        }
    }
    else{
        console.log("[Note] Exact change");
        var tempChange = cashGiven; //a little redundant, but the other functions are rather specific 
        for(i = B20; i <= P; i++){
            while(tempChange - VALUES[i] >= 0){ //while loop; See ../references
                register[i]++;
                tempChange -= VALUES[i];
                tempChange = tempChange.toFixed(2);
            }
        }
        console.log("[Note] Register a/f change: " + register);
    }
}
function dispData(){ //enhancement 2
    //item averages
    var valueHolder;
    for(i = 0; i < FOODTYPES.length; i++){
        for(x = 0; x < eval(FOODTYPES[i]).length; x++){
            valueHolder = eval(avgTotalTypes[i])[x].split(";");
            
            valueHolder[0] = parseInt(valueHolder[0]);
            valueHolder[0] += parseInt(eval(simTotalTypes[i])[x].split(";")[0]);
            
            valueHolder[1] = parseFloat(valueHolder[1]);
            valueHolder[1] += parseFloat(eval(simTotalTypes[i])[x].split(";")[1]);
            valueHolder[1] = parseFloat(valueHolder[1]).toFixed(2);

            eval("op" + eval(FOODTYPES[i])[x].split(";")[0] + "Cost").innerHTML = "~$" + (valueHolder[1] / simNum).toFixed(2);
            eval("op" + eval(FOODTYPES[i])[x].split(";")[0] + "Count").innerHTML = "~" + parseInt(valueHolder[0] / simNum);
            opNumSims.innerHTML = simNum;
            eval(avgTotalTypes[i])[x] = valueHolder.join(";");
        }
    }

    //sales averages
    avgTotalSales += (numElecSales + numCashSales);
    avgTotalSalesTotal += (totalElecSales + totalCashSales);
    avgCashSales += numCashSales;
    avgCashSalesTotal += totalCashSales;
    avgElecSales += numElecSales;
    avgElecSalesTotal += totalElecSales;

    opAvgTotalSaleC.innerHTML = "~" + parseInt(avgTotalSales / simNum);
    opAvgTotalSaleV.innerHTML = "~$" + (avgTotalSalesTotal / simNum).toFixed(2);
    opAvgElecSaleC.innerHTML = "~" + parseInt(avgElecSales / simNum);
    opAvgElecSaleV.innerHTML = "~$" + (avgElecSalesTotal / simNum).toFixed(2);
    opAvgCashSaleC.innerHTML = "~" + parseInt(avgCashSales / simNum);
    opAvgCashSaleV.innerHTML = "~$" + (avgCashSalesTotal / simNum).toFixed(2);
    
    //register balance averages
    avgRegisterBal += parseFloat(dRegisterBal());
    opRegBalValue.innerHTML = "~$" + (avgRegisterBal / simNum).toFixed(2);
}
function dRegisterBal(){ //these loops are starting to get redundant -- i can probably make a more flexible function that'd take in parameters
    var balance = 0;
    for(i = 0; i < register.length; i++)
        for(x = 0; x < register[i]; x++)
            balance += VALUES[i];
    balance = balance.toFixed(2);
    return balance;
}
function setClassStyle(){
    if(!clOrdersWidth || clOrdersWidth < (numOrder * 80))
        clOrdersWidth = (numOrder * 80); //these numbers were very rough estimates through trial and error and are by no means good parameters.
    if(!clReceiptWidth || clReceiptWidth > (82 / numOrder))
        clReceiptWidth = ((82 / numOrder));
    for(i = 0; i < clStyleReceipts.length; i++)
        clStyleReceipts[i].style.width = clReceiptWidth + "%";
    for(i = 0; i <clStyleSims.length; i++)
        clStyleSims[i].style.width = clOrdersWidth +"%";
}
function dispOrder(){ //e for Element
    var eSim = "<span id = 'sim#" + simNum + "' class = 'cSims'></span>";
    opLog.innerHTML += eSim;
    opSims = document.getElementById("sim#" + simNum);
}
function dispReceipt(){ //called per order iteration of a simulation
    var eReceipt = "<span class = 'receipts'> <span class = 'rNum'>Order " + numOrder +"</span>";
    var itemName;
    var itemCost;
    //items ordered
    for(i = 0; i < order.length; i++){
        if(order[i].split(";")[0].includes("_")) //i can probably modify this to make it a more flexible function
            itemName = order[i].split(";")[0].split("_").join(" "); //removes the _ in names that includes it
        else
            itemName = order[i].split(";")[0]; 
        itemCost = order[i].split(";")[1];
        eReceipt += "<br/><span class = 'itemname'>" + itemName + "</span><br/><span class = 'itemcost'>" + itemCost + "</span>";
    }
    //cost totals
    eReceipt += "<br/><span class = 'subtotal'><span class = 'subtotalhead'>Subtotal</span><span class = 'subtotalcost'>" + orderSubTotal + "</span></span>" + //subtotal
                "<br/><span class = 'tax'><span class = 'taxhead'>Tax</span><span class = 'taxcost'>" + orderTax + "</span></span>" + //tax
                "<br/><span class = 'total'><span class = 'totalhead'>Total</span><span class = 'totalcost'>" + orderTotal + "</span></span>"; //total
    //numsales
    eReceipt += "<br/><span class = 'paymentmethod'><span class = 'methodname'>" + paymentMethod + "</span><span class = 'payment'>" + cashGiven + "</span></span>";
    if(paymentMethod == "Cash")
        eReceipt += "<br/><span class = 'paymentchange'><span class = 'changehead'>Change</span><span class = 'changevalue'>" + change + "</span></span>";
    eReceipt += "</span>";
    
    opSims.innerHTML += eReceipt;
}
function dispSimTotals(){ //these get a bit redundant since i didn't plan it aaaaugh
    var itemName;
    var itemCount;
    var itemCost;
    var simSalesTotal = (totalCashSales + totalElecSales).toFixed(2);
    var regBalDiff = parseFloat(dRegisterBal() - totalCashSales).toFixed(2);
    var regBalResult;
    var eSimTotals = "<span class = 'simtotals'><span class = 'simhead'>Sim <span class = 'simnum'>" + simNum + "</span> Totals</span>"
                     "<br/><span class = 'simlabeltab'>Item -- Revenue (Count)</span>";
    //sim item totals
    for(i = 0; i < FOODTYPES.length; i++){
        for(x = 0; x < eval(FOODTYPES[i]).length; x++){
            if(eval(FOODTYPES[i])[x].split(";")[0].includes("_")) //i can probably modify this to make it a more flexible function
                itemName = eval(FOODTYPES[i])[x].split(";")[0].split("_").join(" "); //removes the _ in names that includes it
            else
                itemName = eval(FOODTYPES[i])[x].split(";")[0]; 

            itemCount = eval(simTotalTypes[i])[x].split(";")[0];
            itemCost = eval(simTotalTypes[i])[x].split(";")[1];
            eSimTotals += "<br/><span class = 'simitems'><span class = 'simitemname'>" + itemName + "</span> -- <span class = 'simitemcost'>$" 
            + itemCost + "</span> (<span class = 'simitemcount'>" + itemCount + "</span>)</span>";
        }
    } //.toFixed is necessary here for the float to display as "9.70" instead of "9.7"
    //sim sale totals
    eSimTotals += "<br/><span class = 'simsales'><span class = 'simsalenumhead'>Total Sales</span> -- <span class = 'simsalenumvalue'>$" + simSalesTotal + "</span> (<span class = 'simsalenumnum'>" + (numElecSales + numCashSales) + "</span>)" + 
                  "<br/><span class = 'simsalespecific'><span class = 'simsalenumhead'>Electronic</span> -- <span class = 'simsalenumvalue'>$" + parseFloat(totalElecSales).toFixed(2) + "</span> (<span class = 'simsalenumnum'>" + numElecSales + "</span>)" + 
                  "<br/><span class = 'simsalenumhead'>Cash</span> -- <span class = 'simsalenumvalue'>$" + parseFloat(totalCashSales).toFixed(2) + "</span> (<span class = 'simsalenumnum'>" + numCashSales + "</span>)</span></span>";
    //sim register balance
    eSimTotals += "<br/><span class = 'regbal'><span class = 'regbalhead'>Register Balance</span> -- <span class = 'regbalvalue'>$" + dRegisterBal() + "</span>";
    if(regBalDiff == 100)//determines if under, even, or over
        regBalResult = "Even";
    else if(regBalDiff > 100)
        regBalResult = "Over";
    else
        regBalResult = "Under";
        
    eSimTotals += " (<span class = 'regbalresult'>" + regBalResult + "</span>)</span>"
    opSims.innerHTML = eSimTotals + "</span>" + opSims.innerHTML; ///span closes simhead element
}
/*function resetDisplay(){ //i've learned to use variables for srcs to not need to make a new function for reset. Also, make display more dynamic.
    because I made display the way I did (still showing every simulation result), and because I can't store every single simulation result in a variable due to memory limits, I couldn't
    reset 

    opRegBalAvgs.innerHTML = "";
    opNumSims.innerHTML = "";

    console.log(opSims.innerHTML);
    //opSims.innerHTML = null;
    //opLogs.innerHTML = null;

    opAvgTotalSaleC.innerHTML = "0";
    opAvgTotalSaleV.innerHTML = "0";
    opAvgElecSaleC.innerHTML = "0";
    opAvgElecSaleV.innerHTML = "0";
    opAvgCashSaleC.innerHTML = "0";
    opAvgCashSaleV.innerHTML = "0";
    opRegBalValue.innerHTML = null;
} */
function display(){ //display per simulation
    dispSimTotals();
    dispData();
    setClassStyle();
}